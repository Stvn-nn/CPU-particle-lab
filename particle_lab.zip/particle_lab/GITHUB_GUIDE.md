# Put Particle Lab on GitHub using the website

You do not need Git installed to upload this project.

1. Extract the ZIP first. Open the `particle_lab` folder and confirm that you
   can see `app.py`, `README.md`, and the `web` folder.
2. On GitHub, create a repository with a name such as `particle-lab`.
3. Open its file-upload page. In an existing repository, use **Add file →
   Upload files**. A new empty repository also has an upload link.
4. Drag the **contents inside** `particle_lab` onto that page, including the
   `web`, `training`, `tests`, and `docs` folders. Using drag-and-drop lets a
   supported desktop browser preserve the folder structure.
5. Enter a commit message such as `Add interactive particle lab` and save the
   upload. Your `README.md` should now appear on the repository's main page.

If folder upload is unavailable in your browser, create paths individually with
**Add file → Create new file**. Typing `web/core.js` in the filename creates the
folder and file together; paste the matching file's content. Repeat for the
other paths. This is more work than dragging the project contents.

Keep `web/models/dynamics.json` and `web/models/training_report.json`: the app
needs these trained model assets. Keep `docs/app-screenshot.png` for the README.
Upload the actual source files so visitors can read your code. A ZIP can be an
additional download, but the ZIP alone makes the source harder to review.

Do not upload temporary environments or generated caches such as `.venv`,
`node_modules`, `__pycache__`, or your personal experiment downloads. A provided
`.gitignore` describes these exclusions for future use with Git. GitHub's
website upload does not automatically filter a folder using `.gitignore`, so
leave those directories out when dragging files.

This project does not need a `.env` file or any API keys. The only local website
address is printed when you run `app.py`. Uploading source to a repository does
not itself start the app for visitors; they can download it and run it locally.

Before adding it to your resume, run it yourself and read `LEARN_THE_PROJECT.md`.
Describe measurements you actually observed on your computer. Avoid presenting
software-renderer test timings as performance results from a physical GPU.
